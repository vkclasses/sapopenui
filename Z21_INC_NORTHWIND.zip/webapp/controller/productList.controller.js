sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("dhs.crm.northwind.controller.productList", {
    
     onInit : function(){
      debugger;	
      // Set the sPath
      var sPath = "/V3/northwind/northwind.svc";
      // Getting the Instance of O-Data Model for the Northwind Services
      var oDataModel = new sap.ui.model.odata.v2.ODataModel(sPath);
      // Set the oData Model to the View & give a refernce to the Model. Here we give oNorthwindModel
      this.getView().setModel(oDataModel, "oNorthwindModel");
      // Set the Model to the core as well
      sap.ui.getCore().setModel(oDataModel, "oNorthwindModel");
     }

	});
	
});